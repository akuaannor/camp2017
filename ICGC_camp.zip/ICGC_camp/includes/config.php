<?php  
 define('DB', 'icgc_hgt');
 define('USER', 'root');
 define('PASS', '');
 define('HOST', 'localhost');

 $link = mysql_connect(HOST,USER,PASS);
 if (!$link) {
  die(mysql_error());
 }
 $db_select = mysql_select_db(DB,$link);
 if (!$db_select) {
  die(mysql_error());
  # code...
 }
?>
