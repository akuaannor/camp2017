<?php
$info="";
$alert="";
include_once('config.php');

  if (isset($_POST['Surname'])) {
     $Surname= $_POST['Surname'];
  }

  if (isset($_POST['Othernames'])) {
     $Othernames= $_POST['Othernames'];
  }

  if (isset($_POST['email'])) {
     $email= filter_var(($_POST['email']), FILTER_SANITIZE_EMAIL) ;
  }

  if (isset($_POST['Nationality'])) {
	 $Nationality=$_POST['Nationality'];
   }

  if (isset($_POST['Phonenumber'])) {
     $Phonenumber= $_POST['Phonenumber'];
  }


  if (isset($_POST['Address'])) {
     $Address= $_POST['Address'];
  }

  if (isset($_POST['Assembly'])) {
     $Assembly=$_POST['Assembly'];

  }

  if (isset($_POST['Allergies'])) {
     $Allergies=$_POST['Allergies'];
  }  
  
   if (isset($_POST['ParentsFullName'])) {
	$ParentsFullName=$_POST['ParentsFullName'];
  }  

  if (isset($_POST['ParentsFullName'])) {
  $ParentsFullName=$_POST['ParentsFullName'];
  } 

  if (isset($_POST['ParentsTelephone'])) {
  $ParentsTelephone=$_POST['ParentsTelephone'];
  } 

  if (isset($_POST['Parentsemail'])) {
  $Parentsemail=$_POST['Parentsemail'];
  } 

  if (isset($_POST['Register'])) {

      $btnSubmit = $_POST['Register'];

    $num = 10;
    
    if(empty($Surname) || empty($Othernames) || empty($email) || empty($Phonenumber) || empty($Address)) {

      $alert .= 
        "<div class='col-md-12'>
          <div class='alert alert-warning alert-dismissible' role='alert'>
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
            <strong><center>PLEASE CHECK THAT ALL FIELDS ARE FILLED </center></strong> 
          </div>
        </div>";

    }else if (!is_numeric($Phonenumber))  {
       
      $alert .= 
        "<div class='col-md-12'>
          <div class='alert alert-warning alert-dismissible' role='alert'>
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
            <strong><center>PLEASE PROVIDE A VALID TELEPHONE NUMBER </center></strong> 
          </div>
        </div>"; 
                  
     }else if (strlen($Phonenumber) != $num)  {
       
      $alert .= 
        "<div class='col-md-12'>
          <div class='alert alert-warning alert-dismissible' role='alert'>
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
            <strong><center>PLEASE PROVIDE A 10 DIGIT TELEPHONE NUMBER </center></strong> 
          </div>
        </div>"; 

    } else {
      $result = mysql_query("SELECT * FROM registration WHERE Email='$email' AND Othernames='$Othernames'");
      $data = mysql_num_rows($result);

      if(($data)==0){

          $sql = "INSERT INTO registration (Surname, Othernames, Email, Nationality, Phonenumber, Address, Assembly, Allergies, ParentsFullName, ParentsTelephone, Parentsemail) VALUES('$Surname', '$Othernames', '$email', '$Nationality', '$Phonenumber', '$Address', '$Assembly', '$Allergies', '$ParentsFullName', '$ParentsTelephone', '$Parentsemail')";
                
          if (mysql_query($sql)) {  
            $alert .= 
              "<div class='container'><div class='col-md-12'>
                <div class='alert alert-success alert-dismissible' role='alert'>
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                  <strong><center> Success! </center></strong> 
                </div>
              </div>
              </div>";

              $info .= '
              <div class="jumbotron">
                <h3>Hi, '.ucfirst($Surname).' '.ucfirst($Othernames).'</h3>
                <p>you have completed your registration for the 2017 Omega Generation Camp</p>
                <a href="index" type="button" class="btn btn-default ">Print</a>
              </div>

              ';
              } else { 
                die(mysql_error());
                  echo "Error: " . $sql . "<br>" . mysql_error($conn);
                }
              mysql_close();
      } else {
        $alert .= 
        "<div class='col-md-12'>
          <div class='alert alert-warning alert-dismissible' role='alert'>
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
            <strong><center> You've already registered </center></strong> 
          </div>
        </div>";
      }
    }
        
  }

 ?>