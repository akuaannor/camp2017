<!-- footer -->
</style>
		<div class="footer">
			<div class="container">
				<h3>ICGC HOLY GHOST TEMPLE</h3>
				<p>© 2017 - Youth Department</p>
				<div class="social-icons">
					<ul>
						<li><a href="#" class="fa fa-facebook icon icon-border facebook"> </a></li>
						<li><a href="#" class="fa fa-twitter icon icon-border twitter"> </a></li>
					</ul>
				</div>
			</div>
		</div>
<!-- //footer -->
