$(function () {
	$("surname_error_message").hide();
	$("phonenumber_error_message").hide();
	$("email_error_message").hide();


	var error_surname = false;
	var error_phonenumber = false;
	// var error_email = false;


	$("#form_surname").focusout(function() {
		check_surname();
	});

	$("#form_phonenumber").focusout(function() {
	check_phonenumber();
	});

	// $("#form_email").focusout(function() {
	// check_email();
	// });

	function check_surname() {
		var surname_length = $("#form_surname").val().length;

		if (surname_length < 5 || surname_length > 20) {
			$("#surname_error_message").html("Wow! Your surname is less than 5 letters?");
			$("#surname_error_message").show();
			error_surname = true;
		} else {
			$("#surname_error_message").hide();
		}
	}

	function check_phonenumber() {
	var phone_length = $("#form_phonenumber").val().length;

	if (phone_length < 9) {
		$("#phonenumber_error_message").html("Come on,you know the number has to be 10 digits.Check again");
		$("#phonenumber_error_message").show();
		error_phonenumber = true;
	} else {
		$("#phonenumber_error_message").hide();
	}
}
	
	function check_email() {
	var pattern = new RegExp(/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/);

	if (pattern.test($("#form_email").val())) {
		$("#email_error_message").hide();
	} else {
		$("#email_error_message").html("Looks like you entered an invalid email");
		$("#email_error_message").show();
		email_error = true;
	}
}

	$("#registration_form").submit(function() {
		error_surname = false;
		error_phonenumber = false;
		// error_email = false;

		check_surname();
		check_phonenumber();
		// check_email();
		if (error_surname == false && error_phonenumber == false) {
			return true;
		} else {
						alert("Please correct the errors before you can register");
			return false;
		}
	});
});