<?php include 'database.php'; ?>
<!DOCTYPE html>
<html>
  <head>
    <title>CCCC</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>
<body style="background-color: smokewhite;">










<div id="mySidenav" class="sidenav ">
  
  <div class="topimgcover" >
      <!-- <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a> -->
      <img src="image/avatar.png">
      <p style="color: white;">Adim name</p>      
   </div> 
   <div>
      <a href="#">About</a>
      <a href="#">Services</a>
      <a href="#">Clients</a>
      <a href="#">Contact</a>
   </div>
 
</div>

<!-- <div id="main">
  <h2>Sidenav Push Example</h2>
  <p>Click on the element below to open the side navigation menu, and push this content to the right.</p>
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

  <div> -->
    
                    <?php 
                                     
                        $id = $_GET['id'];
                        $row= $conn->query("SELECT * FROM users WHERE id = '$id'");
                        $rows= $row->fetch_array();

                        // print_r($rows);
                    ?>
      
        <div class="container">
          <div class="row">
            <div class="pagetitle col-md-3 col-md-offset-2 " style="width: 900;">
              <p style="font-weight: bold; font-size: 16px;"><?php echo $rows['username'] .'\'s';  ?> DETAILS</p>
            </div>
            
          </div>


          <div class="row">
            <!-- <div class="col-md-12"> -->
            <div class="adduserdiv col-md-8 col-md-offset-2">
            <!-- <p style="font-size: 18px; font-weight: bold;">Add User</p> -->
           
              <form action="" method="POST" class="form-group col-md-12">
                          
                          <div class="adddiv col-md-2">
                            <label class="form-label">ID</label>
                            <input class="form-control" readonly="" type=""  name="id" placeholder="<?php echo $rows['id'];?>">
                            </div>

                           

                           <div class="in col-md-3">
                            <label class="form-label" >Surname</label>
                            <input class="form-control" type="text" name="surname" placeholder="<?php echo $rows['surname'];?>">
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">Firstname</label>
                            <input class="form-control" type="text" name="firstname" placeholder="<?php echo $rows['firstname'];?>">
                            </div>

                            <div class="in col-md-4">
                            <label class="form-label">Username</label>
                            <input style="color: black;" class="form-control" type="text" name="username" placeholder="<?php echo $rows['username'];?>">
                            </div>

                            <div class="in col-md-4">
                            <label class="form-label">E-mail</label>
                            <input class="form-control" type="email" name="email" placeholder="<?php echo $rows['email'];?>">
                            </div>

                            <div class="in col-md-4">
                            <label class="form-label">Phone Number</label>
                            <input class="form-control" type="text" name="phone_num" placeholder="<?php echo $rows['phone_num'];?>">
                            </div>                           

                            <div class="in col-md-4">
                            <label class="form-label">Church</label>
                            <input class="form-control" type="text" name="Church" placeholder="<?php echo $rows['church'];?>">
                            </div>

                           <!--  <div class="in col-md-3">
                            <label class="form-label">Assembly / Branch</label>
                            <input class="form-control" type="text" name="assembly" placeholder="">
                            </div> -->



                            <!-- <div class="in col-md-2 col-md-offset-5"> -->
                            <button class="col-md-2 col-md-offset-5 btn btnadduser">Update</button>
                            <!-- </div> -->
                            



                        </form>



            </div>
          </div>
       </div>
        
  















<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
     
</body>
</html> 
