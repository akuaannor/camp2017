<!DOCTYPE html>
<html>
  <head>
    <title>CCCC</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>
<body style="background-color: smokewhite;">







<div id="mySidenav" class="sidenav ">
  
  <div class="topimgcover" >
      <!-- <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a> -->
      <img src="image/avatar.png">
      <p style="color: white;">Adim name</p>      
   </div> 
   <div>
      <a href="#">About</a>
      <a href="#">Services</a>
      <a href="#">Clients</a>
      <a href="#">Contact</a>
   </div>
 
</div>

<!-- <div id="main">
  <h2>Sidenav Push Example</h2>
  <p>Click on the element below to open the side navigation menu, and push this content to the right.</p>
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

  <div> -->
    

      
        <div class="container">
          <div class="row">
            <div class="pagetitle col-md-4 col-md-offset-4 " style="margin-top: 140px;">
              <p style="font-weight: bold; font-size: 16px;">LOGIN</p>
            </div>
            
          </div>


          <div class="row">
            <!-- <div class="col-md-12"> -->
            <div class="adduserdiv col-md-4 col-md-offset-4">
            <!-- <p style="font-size: 18px; font-weight: bold;">Add User</p> -->
           
              <form action="loginCheck.php" method="POST" class="form-group col-md-12">
                          <!-- <center>
                              <img src="image/logo.png" class="responsive-img" style="width: 60px; height: 60px; margin-bottom: 30px;">
                          </center> -->
                           <!-- <div class="col-md-6 col-md-offset-3">
                                <img src="image/logo.png" class="responsive-img" style="width: 60px; height: 60px;">
                           </div> -->
                           <!-- <div class="adddiv col-md-12"> -->
                            
                           <div class="in col-md-12" style="margin-top: 40px;">
                          
                            <label class="form-label" >Username</label>
                            <input class="form-control" type="text" name="username" placeholder="" style="border: 1.5px solid #115639;">
                            </div>

                            <div class="in col-md-12">
                            <label class="form-label">Password</label>
                            <input class="form-control" type="password" name="password" placeholder="" style="border: 1.5px solid #115639;">
                            </div>

                            <div class="col-md-6 col-md-offset-3">
                            <button class="btn btnlogin" type="submit" name="loginbtn">Login</button>
                            </div>
                            



                        </form>



            </div>
          </div>
       </div>
        
  


<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
     
</body>
</html> 
