<?php include 'database.php' ?>
<!DOCTYPE html>
<html>
  <head>
    <title>CCCC</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>
<body style="background-color: smokewhite;">










<div id="mySidenav" class="sidenav ">
  
  <div class="topimgcover" >
      <!-- <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a> -->
      <img src="image/avatar.png">
      <p style="color: white;">Adim name</p>      
   </div> 
   <div>
      <a href="#">About</a>
      <a href="#">Services</a>
      <a href="#">Clients</a>
      <a href="#">Contact</a>
   </div>
 
</div>

<!-- <div id="main">
  <h2>Sidenav Push Example</h2>
  <p>Click on the element below to open the side navigation menu, and push this content to the right.</p>
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

  <div> -->
    
                  <?php 
                                     
                        $id = $_GET['id'];
                        $row= $conn->query("SELECT * FROM campers WHERE id = '$id'");
                        $rows= $row->fetch_assoc();

                        // print_r($rows);
                    ?>
      
        <div class="container">
          <div class="row">
            <div class="pagetitle col-md-3">
              <p style="font-weight: bold; font-size: 16px;"><?php echo $rows['surname'] ." ". $rows['firstname'] .'\'s';  ?> Details</p>
            </div>
            
          </div>


          <div class="row">
            <!-- <div class="col-md-12"> -->
            <div class="adduserdiv col-md-12">
            <!-- <p style="font-size: 18px; font-weight: bold;">Add User</p> -->
           
              <form action="" method="POST" class="form-group col-md-12">
                          
                          <div class="adddiv col-md-3">
                            <label class="form-label">ID</label>
                            <input class="form-control" readonly="" type="" name="id" placeholder="<?php echo $rows['id'];?>"> 
                            </div>

                           

                           <div class="in col-md-3">
                            <label class="form-label" >Surname</label>
                            <input class="form-control" type="text" name="surname" placeholder="<?php echo $rows['surname'];?>">
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">Firstname</label>
                            <input class="form-control" type="text" name="firstname" placeholder="<?php echo $rows['firstname'];?>">
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">Other Name</label>
                            <input style="color: black;" class="form-control" type="text" name="othername" placeholder="<?php echo $rows['othername'];?>">
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">E-mail</label>
                            <input class="form-control" type="email" name="email" placeholder="<?php echo $rows['email'];?>">
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">Phone Number</label>
                            <input class="form-control" type="text" name="phone_num" placeholder="<?php echo $rows['phone_num'];?>">
                            </div>                           

                            <div class="in col-md-3">
                            <label class="form-label">Date Of Birth</label>
                            <input class="form-control" type="date" name="dob" placeholder="<?php echo $rows['dob'];?>">
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">Sex</label>
                            <input class="form-control" type="text" name="sex" placeholder="<?php echo $rows['sex'];?>">
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">City</label>
                            <input class="form-control" type="text" name="City" placeholder="<?php echo $rows['city'];?>">
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">Nationality</label>
                            <input class="form-control" type="text" name="nationality" placeholder="<?php echo $rows['nationality'];?>">
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">Church</label>
                            <input class="form-control" type="text" name="Church" placeholder="<?php echo $rows['church'];?>">
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">Assembly / Branch</label>
                            <input class="form-control" type="text" name="assembly" placeholder="<?php echo $rows['assembly'];?>">
                            </div>

                            <div class="in col-md-6">
                            <label class="form-label">Special Health Issues</label>
                            <textarea class="form-control" name="health" placeholder="<?php echo $rows['health'];?>"></textarea>
                            </div>

                            <div class="in col-md-6">
                            <label class="form-label">Diet Issues</label>
                            <textarea class="form-control" name="diet" placeholder="<?php echo $rows['diet'];?>"></textarea>
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">Parent / Guardian Name</label>
                            <input class="form-control" type="text" name="fam_name" placeholder="<?php echo $rows['fam_name'];?>">
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">Parent / Guardian Number</label>
                            <input class="form-control" type="phone" name="fam_num" placeholder="<?php echo $rows['fam_num'];?>">
                            </div>

                            <div class="in col-md-3">
                            <label class="form-label">Parent / Guardian E-mail</label>
                            <input class="form-control" type="email" name="fam_mail" placeholder="<?php echo $rows['fam_email'];?>">
                            </div>


                            <!-- <div class="in col-md-2 col-md-offset-5"> -->
                            <button class="col-md-2 col-md-offset-5 btn btnadduser" name="updatecamper" id="updatecamper">Update</button>
                            <!-- </div> -->
                        
                        </form>



            </div>
          </div>


          <!-- payment details -->
          <div class="row">
            <!-- <div class="col-md-12"> -->
            <div class="adduserdiv col-md-12">
            <!-- <p style="font-size: 18px; font-weight: bold;">Add User</p> -->
           
              <!-- <form action="" method="POST" class="form-group col-md-12"> -->
                          
                 <table class="table table-bordered table-inverse">
                   <thead style="background-color: #115639; color: white;">
              <?php 

                $id = $_GET['id'];
                $pdetail = $conn->query("SELECT * FROM payments WHERE user_id = '$id'");
                $pdetails = $pdetail->fetch_assoc();
              
               ?>
                     <tr>
                       <th>Amount</th>
                       <th>Date</th>
                       <th>Paid to</th>
                     </tr>
                   </thead>

                   <tbody>
                     <tr>
                       <td><?php echo $pdetails['amount'];  ?></td>
                       <td><?php echo $pdetails['date_paid'];  ?></td>
                       <!-- echo user who handled the payment -->
                     </tr>
                   </tbody>
                 </table>         
                        
             <!-- </form> -->



            </div>
          </div>



       </div>
        
  















<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
     
</body>
</html> 
