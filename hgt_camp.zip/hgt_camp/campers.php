<?php  
include 'database.php';

?>

<!DOCTYPE html>
<html>
  <head>
    <title>CCCC</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>
<body style="background-color: smokewhite;">










<div id="mySidenav" class="sidenav ">
  
  <div class="topimgcover" >
      <!-- <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a> -->
      <img src="image/avatar.png">
      <p style="color: white;">Adim name</p>      
   </div> 
   <div>
      <a href="#">About</a>
      <a href="#">Services</a>
      <a href="#">Clients</a>
      <a href="#">Contact</a>
   </div>
 
</div>

<!-- <div id="main">
  <h2>Sidenav Push Example</h2>
  <p>Click on the element below to open the side navigation menu, and push this content to the right.</p>
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

  <div> -->
    

      
        <div class="container">

                    <div class="row filterdiv">
                      <div class="col-md-6 col-md-offset-3">
                            <form action="" method="POST" class=" form-group ">
                                <!-- <center>
                                  <label style="color: #115639; font-size: 30px;" class="form-label">Filter</label>
                                </center> -->

                                <input onkeyup="filterbro()" style="color:  #115639; border:2px solid #115639;" class="form-control col-sm-6" type="text" name="search" id="myinput" placeholder="Search by Surname ">

                            </form><br><br>
                      </div>
                    </div>    

          <div class="row pagetitle col-md-3">
            <div class=" col-md-12">
              <p style="font-weight: bold; font-size: 16px;">CAMPERS</p>
            </div>
            <!-- <div class=" col-md-6">
              <form action="" method="POST" class=" form-group ">
                 
                 <input onkeyup="filterbro()" style="color:  #115639; border:2px solid #115639;" class="form-control col-sm-6" type="text" name="search" id="myinput" placeholder="Search by Surname ">

               </form>
            </div> -->
            
          </div>


                      

          <div class="row">
            <!-- <div class="col-md-12"> -->
            <div class="adduserdiv col-md-12">
            <!-- <p style="font-size: 18px; font-weight: bold;">Add User</p> -->
           <table id="camperstable" class="table table-bordered table-inverse" >
                                          <thead style="background-color: #115639; color: white;" >
                                            <tr style="">
                                              <!-- <th>#</th> -->
                                              <th>ID</th>
                                              <th>Surname</th>
                                              <th>First Name</th>
                                              <th>Sex</th>
                                              <th>Church/branch</th>
                                              <th>Contact</th>
                                              <th>form</th>
                                              <th>paid</th>                                          
                                            </tr>
                                          </thead>
                                          <tbody>
                                     
                                            <?php

                                               $result = $conn->query("SELECT * FROM campers");
                                                $results = $result->fetch_array();
                                                // print_r($results);
                                                $rowcount=mysqli_num_rows($result);

                                                  while($results==true) : ?>

                                        <tr>
                                            <!--Each table column is echoed in to a td cell-->
                                            <td><a  href="campers_detail.php?id=<?php echo $results['id']; ?>"><?php echo $results['id']; ?></a></td>
                                            <td><?php echo $results['surname']; ?></td>
                                            <td><?php echo $results['firstname']; ?></td>
                                            <td><?php echo $results['sex']; ?></td>
                                            <td><?php echo $results['church']; ?></td>
                                            <td><?php echo $results['phone_num']; ?></td>

                                            <!-- <form action="paymentCtrl.php" method="POST"> -->
                                              <td><button class="btn btn-primary col-md-12" type="submit" name="submitted">Submitted</button></td>
                                              <td><button class="btn btn-success col-md-12" type="button"  data-toggle="modal" data-target="#myModal">Paid</button></td>
                                            <!-- </form>  -->
                                            

                                            </tr>


                                            <div class="modal fade" id="myModal" role="dialog">
                                              <div class="modal-dialog">
                                              
                                                <!-- Modal content-->
                                                <div class="modal-content">
                                                  <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <h4 class="modal-title"><?php echo $results['surname'] . " ".$results['firstname'] ; ?></h4>
                                                  </div>

                                              <form action="paymentCtrl.php" method="POST">
                                                  <div class="modal-body">
                                                    <!-- <div class="in col-md-3"> -->
                                                    
                                                      <label class="form-label">Enter Amount:</label>
                                                      <input class="form-control" type="text" name="fee" placeholder="00.00">
                                                      <input type="hidden" name="camperid" value="<?php $results['id'] ?>" />
                                                    
                                                      <!-- </div> -->
                                                  </div>
                                                  <div class="modal-footer">
                                                    <button type="submit" class="btn btnlogin" name="amount" style="">Enter</button>
                                                    <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                                                  </div>
                                                  </form>
                                                </div>
                                              
                                              </div>
                                            </div>


                                            <?php $results = $result->fetch_array(); 
                                              endwhile 
                                            ?>
                                      </tbody>
                                  </table>





                                      
      
  













<script src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script>

// $('#myModal').on('shown.bs.modal', function () {
//   $('#myInput').focus()
// })


function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}

function filterbro() {
      var input, filter, table, tr, td, i;
      input = document.getElementById("myinput");
      filter = input.value.toUpperCase();
      table = document.getElementById("camperstable");
      tr = table.getElementsByTagName("tr");
      for (i = 1; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[1];
        if (td) {
          if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
            tr[i].style.display = "";
          } else {
            tr[i].style.display = "none";
          }
        }       
      }
    }
</script>

     
</body>
</html> 
