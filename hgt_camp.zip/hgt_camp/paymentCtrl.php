<?php 

include 'database.php';


if (isset($_POST['submitted'])) {
	# code...
	$submit = $conn->query("INSERT INTO campers submitted VALUES CURRENT_TIMESTAMP");
}


if (isset($_POST['amount'])) {
	
	$camperid =$_POST['camperid'];
	$fee = $_POST['fee'];
	$paid = $conn->query("INSERT INTO payments (user_id, amount, date_paid) VALUES ('$camperid', '$fee', CURRENT_TIMESTAMP)");

	if ($paid==true) {
		echo "done";
	}
	else
		echo "sorry";
}



 ?>