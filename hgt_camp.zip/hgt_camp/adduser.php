<?php 

include 'database.php';



// error_reporting(E_ALL);
    // session_start();

			  
     
    //  $user_name= $_SESSION['user']['user_name']; 
     // $user_ = $_SESSION['user'][''];

      if(isset($_POST['adduserbtn']))
         {
                                  // collecting data entered into form controls
	          $surname = $_POST['surname'];
	          $firstname = $_POST['firstname'];
	          $username = $_POST['username'];
	          $password = md5($_POST['password']);
	          // $password2 = md5($_POST['password2']);
	          $email = $_POST['email'];
	          $phone_num = $_POST['phone_num'];
	          $user_role = $_POST['user_role'];
	          $church = $_POST['church'];

	                                  // $chkb ="";
	          $addusers= $conn->query("INSERT INTO users (username, surname, firstname, password, email, phone_num, user_role, church) VALUES ('$username', '$surname', '$firstname', '$password','$email', '$phone_num', '$user_role', '$church' )");
	          
	          header('location:home.php');

	      }


	      
	      // if (isset($_POST['editbtn'])) {
	      	
	      	

	      // }

	      // elseif (isset($_POST['deletebtn'])) {
	      	
	      // 	echo "Are you sure you want to delete user?";

	      // 	if (isset($_POST['yesbtn'])) {
	      		
	      // 		$del =$sql->query("DELETE * users WHERE user_id= '$id'");
	      // 	}

	      // }


 ?>