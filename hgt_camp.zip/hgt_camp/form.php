<!DOCTYPE html>
<html>
  <head>
    <title>CCCC</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>
<body style="background-color: smokewhite;">









<!-- <div id="main">
  <h2>Sidenav Push Example</h2>
  <p>Click on the element below to open the side navigation menu, and push this content to the right.</p>
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

  <div> -->
    

      
        <div class="container">
          <div class="row">
            <div class="pagetitle col-md-4 col-md-offset-1 " style="margin-top:40px;">
              <p style="font-weight: bold; font-size: 16px;">OMEGA GENERATION CAMP - 2017</p>
            </div>
            
          </div>


          <div class="row">
            <!-- <div class="col-md-12"> -->
            <div class="adduserdiv col-md-10 col-md-offset-1" style="padding-top: 40px;">
            <!-- <p style="font-size: 18px; font-weight: bold;">Add User</p> -->
           
              <form action="formControl.php" method="POST" class="form-group">
                          
                            
                           <div class="in col-md-6" >
                          
                            <label class="form-label" >Surname</label>
                            <input class="form-control" type="text" name="surname" placeholder="" style="border: 1px solid #115639;">
                            </div>

                            <div class="in col-md-6">
                              <label class="form-label" >First Name</label>
                              <input class="form-control" type="text" name="firstname" placeholder="" style="border: 1px solid #115639;">
                            </div>

                            <div class="in col-md-6">
                              <label class="form-label" >Other Name</label>
                              <input class="form-control" type="text" name="othername" placeholder="" style="border: 1px solid #115639;">
                            </div>

                            <div class="in col-md-3">
                              <label class="form-label" >Date of Birth</label>
                              <input class="form-control" type="text" name="dob" placeholder="" style="border: 1px solid #115639;">
                            </div>

                            <div class="in col-md-3">
                              <label class="form-label" >Sex</label>
                              <select name="sex" class="form-control" style="border: 1px solid #115639;">
                                <option value="female">Female</option>
                                <option value="male">Male</option>
                              </select>
                            </div>

                            <div class="in col-md-6">
                              <label class="form-label" >Phone Number</label>
                              <input class="form-control" type="text" name="phone_num" placeholder="" style="border: 1px solid #115639;">
                            </div>

                            <div class="in col-md-6">
                              <label class="form-label" >E-mail</label>
                              <input class="form-control" type="email" name="email" placeholder="" style="border: 1px solid #115639;">
                            </div>

                            <div class="in col-md-6">
                              <label class="form-label" >City</label>
                              <input class="form-control" type="text" name="city" placeholder="" style="border: 1px solid #115639;">
                            </div>

                            <div class="in col-md-6">
                              <label class="form-label" >Nationality</label>
                              <input class="form-control" type="text" name="nationality" placeholder="" style="border: 1px solid #115639;">
                            </div>

                            <div class="in col-md-6">
                            <label class="form-label">Church</label>
                            <input class="form-control" type="text" name="church" placeholder="" style="border: 1px solid #115639;">
                            </div>

                            <div class="in col-md-6">
                            <label class="form-label">Assembly / Branch</label>
                              <select name="assembly" class="form-control">
                                <option value="holy ghost temple">Holy Ghost Temple</option>
                                <option value="joy temple">Joy Temple</option>
                                <option value="liberty temple">Liberty Temple</option>
                                <option value="open heavens temple">Open Heavens Temple</option>
                                <option value="prayer temple">Prayer Temple</option> 
                                <option value="seekers temple">Seekers Temple</option>
                                <option value="salem temple">Salem Temple</option>
                                <option value="shammah temple">Shammah Temple</option>
                                <option value="yahweh temple">Yahweh Temple</option>
                              </select>
                            </div>

                            <div class="in col-md-6">
                            <label class="form-label">Special Health Issues</label>
                            <textarea class="form-control" name="health" placeholder="" style="border: 1px solid #115639;"></textarea>
                            </div>

                            <div class="in col-md-6">
                            <label class="form-label">Diet Issues</label>
                            <textarea class="form-control" name="diet" placeholder="" style="border: 1px solid #115639;"></textarea>
                            </div>

                            <div class="in col-md-4">
                            <label class="form-label">Parent / Guardian Name</label>
                            <input class="form-control" type="text" name="fam_name" placeholder="" style="border: 1px solid #115639;">
                            </div>



                            <div class="in col-md-4">
                            <label class="form-label">Parent / Guardian Number</label>
                            <input class="form-control" type="phone" name="fam_num" placeholder="" style="border: 1px solid #115639;">
                            </div>

                            <div class="in col-md-4">
                            <label class="form-label">Parent / Guardian E-mail</label>
                            <input class="form-control" type="email" name="fam_mail" placeholder="" style="border: 1px solid #115639;">
                            </div>

                            <div class="col-md-12 ">
                            <button class="btn btnlogin" type="submit" name="submitbtn">SUBMIT</button>
                            </div>
                            



                            <div>
                              
                            </div>


                        </form>



            </div>
          </div>
       </div>
        
  


<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
     
</body>
</html> 
