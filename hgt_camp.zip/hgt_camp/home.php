<?php include 'database.php'; ?>
<!DOCTYPE html>
<html>
  <head>
    <title>CCCC</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>
<body style="background-color: smokewhite;">










<div id="mySidenav" class="sidenav ">
  
  <div class="topimgcover" >
      <!-- <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a> -->
      <img src="image/avatar.png">
      <p style="color: white;">Adim name</p>      
   </div> 
   <div>
      <a href="#">About</a>
      <a href="#">Services</a>
      <a href="#">Clients</a>
      <a href="#">Contact</a>
   </div>
 
</div>

<!-- <div id="main">
  <h2>Sidenav Push Example</h2>
  <p>Click on the element below to open the side navigation menu, and push this content to the right.</p>
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

  <div> -->
    

      
        <div class="container">
          <div class="row">
            <div class="pagetitle col-md-3">
              <p style="font-weight: bold; font-size: 16px;">ADD USER</p>
            </div>
            
          </div>


          <div class="row">
            <!-- <div class="col-md-12"> -->
            <div class="adduserdiv col-md-12">
            <!-- <p style="font-size: 18px; font-weight: bold;">Add User</p> -->
              <form action="adduser.php" method="POST" class="form-group ">
              
                <div class="col-md-3 in">
                  <label class="control-label">Surname</label>
                  <input type="text" name="surname" class="form-control">
                </div>

                <div class="col-md-3 in">
                  <label class="control-label">First Name</label>
                  <input type="text" name="firstname" class="form-control">
                </div>

                <div class="col-md-6 in">
                  <label class="control-label">Username</label>
                  <input type="text" name="username" class="form-control">
                </div>

                
                <div class="col-md-3 in">
                  <label class="control-label">E-mail</label>
                  <input type="" name="email" class="form-control">
                </div>

                <div class="col-md-3 in">
                  <label class="control-label">Phone Number</label>
                  <input type="" name="phone_num" class="form-control">
                </div>

                <div class="col-md-3 in">
                  <label class="control-label">Password</label>
                  <input type="password" name="password" class="form-control">
                </div>

                <!-- <div class="col-md-3 in">
                  <label class="control-label">Confirm Password</label>
                  <input type="" name="password2" class="form-control">
                </div> -->

                <div class="col-md-6 in">
                <label class="control-label"> Church/Brnch </label>
                  <select name="church" class="form-control">
                  <option name="church" value="holy ghost temple">Holy Ghost Temple</option>
                  <option name="church" value="joy temple">Joy Temple</option>
                  <option name="church" value="liberty temple">Liberty Temple</option>
                  <option name="church" value="open heavens temple">Open Heavens Temple</option>
                  <option name="church" value="prayer temple">Prayer Temple</option> 
                  <option name="church" value="seekers temple">Seekers Temple</option>
                  <option name="church" value="salem temple">Salem Temple</option>
                  <option name="church" value="shammah temple">Shammah Temple</option>
                  <option name="church" value="yahweh temple">Yahweh Temple</option>
                </select>
                </div>

            
                <div class="col-md-6 in">
                <label class="control-label"> User Role </label>
                  <select name="user_role" class="form-control">
                  <option name="user_role" value="camp officer" class="active">Camp Officer</option>
                  <option name="user_role" value="committee member" >Camp Committee</option> 
                  <option name="user_role" value="admin">Admin</option> 
                </select>
                </div>
                
                <button class="col-md-2 col-md-offset-5 btn btnadduser" name="adduserbtn" id="adduserbtn" type="submit">Add User</button>
              <!-- </div> -->
              </form>
            <!-- </div> -->
          </div>
          


          <div class="adduserdiv col-md-12">
              <table id="mytable" class="table table-bordered table-inverse" >
                                          <thead style="background-color: #115639; color: white;" >
                                            <tr style="">
                                              <th>#</th>
                                              <th>Usename</th>
                                              <th>Surname</th>
                                              <th>First Name</th>
                                              <th>Phone Number</th>
                                              <th>Church/branch</th>
                                              <th>role</th>
                                              <!-- <th>Edit</th>
                                              <th>Delete</th> -->
                                              
                                            </tr>
                                          </thead>
                                          <tbody>
                                            <?php 
                                              // include 'adduser.php';

                                              $result = $conn->query("SELECT * FROM users");
                                              $addusers = $result->fetch_array();
                                              // print_r($results);
                                              $rowcount=mysqli_num_rows($result);

                                              while($addusers ==true) :  ?>
                                     
                                            <tr>
                                            <td><a  href="user_detail.php?id=<?php echo $addusers['id']; ?>"><?php echo $addusers['id']; ?></a></td>
                                            <td><?php echo $addusers['username']; ?></td>
                                            <td><?php echo $addusers['surname']; ?></td>
                                            <td><?php echo $addusers['firstname']; ?></td>
                                            <td><?php echo $addusers['phone_num']; ?></td>
                                            <td><?php echo $addusers['church']; ?></td>
                                            <td><?php echo $addusers['user_role']; ?></td>
                                            <td><button class="btn btn-success col-md-12" name="editbtn">Edit</button></td>
                                            <td><button class="btn btn-danger col-md-12" name="deletebtn">Delete</button></td>
                                            
                                        </tr>
                                        <?php $addusers = $result->fetch_array(); 
                                              endwhile
                                          ?>
                                      </tbody>
                                  </table>
            
          </div>
       </div>
        
      
  </div>

</div>

















<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>
     
</body>
</html> 
