<?php

include 'database.php';
// Escape email to protect against SQL injections
// $email = $mysqli->escape_string($_POST['email']);
// session_start();
if(isset($_POST['loginbtn']))
    {

// $username = $_POST['username'];
// $password = md5($_POST['password']);

$username = mysqli_real_escape_string($conn, $_POST['username']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

$password = md5($password);
}

$log = $conn->query("SELECT * FROM users WHERE username='$username' AND password ='$password'");
// $results = $log->fetch_assoc();

$count = mysqli_num_rows($log);
// $_SESSION['user'] = $results;
// $id= $_SESSION['user']['id'];
// $user_name =$_SESSION['user']['username'];

        print_r($log);





?>